


<p align="center">
  <img src="https://img.shields.io/badge/Author-Siddhant Saaho-cyan?style=flat-square">
  <img src="https://img.shields.io/badge/Open%20Source-Yes-cyan?style=flat-square">
  <img src="https://img.shields.io/badge/MADE%20IN-Tamil Eelam-green?colorA=%23ff0000&colorB=%23017e40&style=flat-square">
  <img src="https://img.shields.io/badge/Written%20In-Bash-cyan?style=flat-square">
</p>

<p align="center">A beginners friendly, Automated Basic Tool.</p>

##

### Features

- Beginners friendly 
- Requirements Installing 
- Hack  `Mobile or Computer Camera` With a Link

### Installation

- Just, Clone this repository -
```
$ git clone https://github.com/SiddhantOffl/cam-virus.git
```

- Change to cloned directory and run `cam_virus.sh` -
```
$ cd basic
$ bash cam_virus.sh
```

- On first launch, It'll install the dependencies and that's it. `cam_virus.sh` is installed.







### Find Me on :
<p align="left">
  <a href="https://github.com/SiddhantOffl" target="_blank"><img src="https://img.shields.io/badge/Github-SiddhantOffl-green?style=for-the-badge&logo=github"></a>
  <a href="https://www.instagram.com/yadhav_offl" target="_blank"><img src="https://img.shields.io/badge/IG-%40Yadhav_offl-red?style=for-the-badge&logo=instagram"></a>
  
</p>
